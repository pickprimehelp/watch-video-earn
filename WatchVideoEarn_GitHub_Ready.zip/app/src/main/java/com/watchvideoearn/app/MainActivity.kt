package com.watchvideoearn.app

import android.content.ContentValues
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.pow

class MainActivity : ComponentActivity() {

    private lateinit var root: LinearLayout
    private lateinit var balanceText: TextView
    private var balance = 0.0
    private var rewardedAd: RewardedAd? = null
    private var interstitialAd: InterstitialAd? = null
    private val prefs by lazy { getSharedPreferences("wallet", MODE_PRIVATE) }

    private val purple = Color.rgb(103, 80, 164)
    private val bg = Color.rgb(247, 245, 250)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        balance = prefs.getFloat("balance", 0f).toDouble()
        MobileAds.initialize(this) {}
        loadRewarded()
        loadInterstitial()
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = s
            textSize = size
            setTextColor(Color.rgb(35, 32, 40))
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }

    private fun button(s: String, action: () -> Unit): Button =
        Button(this).apply {
            text = s
            setOnClickListener { action() }
            isAllCaps = false
        }

    private fun input(hint: String, value: String = ""): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(5), 0, dp(5)) }
        }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        root.addView(text(title, 25f, true))
    }

    private fun adBanner() {
        val ad = AdView(this).apply {
            adSize = com.google.android.gms.ads.AdSize.BANNER
            adUnitId = "ca-app-pub-3940256099942544/6300978111"
            loadAd(AdRequest.Builder().build())
        }
        root.addView(ad, LinearLayout.LayoutParams(-1, dp(55)))
    }

    private fun card(title: String, action: () -> Unit) {
        val b = button(title, action)
        b.layoutParams = LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(0, dp(4), 0, dp(4)) }
        root.addView(b)
    }

    private fun showHome() {
        base("Watch Video & Earn Real Money")
        balanceText = text("", 18f, true)
        root.addView(balanceText)
        updateBalance()
        adBanner()
        root.addView(text("Rewarded video earning (test/demo)", 15f))
        card("▶ Watch Video & Earn", ::watchReward)
        card("💰 Wallet & Withdrawal", ::wallet)
        root.addView(text("Tools", 20f, true))
        card("🖼 Status Maker", ::statusMaker)
        card("💍 Wedding Card Generator", ::wedding)
        card("🧾 GST Invoice Maker", ::invoice)
        card("🧮 GST Calculator", ::gstCalculator)
        card("➗ Basic Calculator", ::calculator)
        card("📊 EMI Calculator", ::emi)
        card("🎂 Age Calculator", ::age)
        card("🏷 Discount Calculator", ::discount)
        card("🍽 Tip Calculator", ::tip)
        card("⚖ BMI Calculator", ::bmi)
        card("💬 Quote Maker", ::quote)
        card("✨ Name Style Maker", ::nameStyle)
        root.addView(text("Test ads are used. Real money requires a secure server and payout provider.", 13f))
    }

    private fun updateBalance() {
        if (::balanceText.isInitialized) balanceText.text = "Wallet balance: ₹%.2f".format(balance)
    }

    private fun saveBalance() {
        prefs.edit().putFloat("balance", balance.toFloat()).apply()
        updateBalance()
    }

    private fun loadRewarded() {
        RewardedAd.load(this, "ca-app-pub-3940256099942544/5224354917",
            AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { rewardedAd = null }
            })
    }

    private fun watchReward() {
        val ad = rewardedAd
        if (ad == null) {
            Toast.makeText(this, "Rewarded test ad is loading. Please try again.", Toast.LENGTH_SHORT).show()
            loadRewarded()
            return
        }
        ad.show(this) {
            // Demo only. Production must verify the reward on a server.
            balance += 1.0
            saveBalance()
            Toast.makeText(this, "Demo reward ₹1 added", Toast.LENGTH_SHORT).show()
            loadRewarded()
        }
        rewardedAd = null
    }

    private fun loadInterstitial() {
        InterstitialAd.load(this, "ca-app-pub-3940256099942544/1033173712",
            AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitialAd = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitialAd = null }
            })
    }

    private fun afterDownload(action: () -> Unit) {
        val ad = interstitialAd
        if (ad == null) {
            action()
            loadInterstitial()
        } else {
            ad.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() { action(); loadInterstitial() }
                override fun onAdFailedToShowFullScreenContent(e: com.google.android.gms.ads.AdError) { action(); loadInterstitial() }
            }
            interstitialAd = null
            ad.show(this)
        }
    }

    private fun wallet() {
        base("Wallet")
        root.addView(text("Current demo balance: ₹%.2f".format(balance), 24f, true))
        root.addView(text("Minimum demo withdrawal: ₹100", 15f))
        val upi = input("UPI ID")
        root.addView(upi)
        root.addView(button("Request UPI Withdrawal (Demo)") {
            if (balance < 100) Toast.makeText(this, "Minimum balance is ₹100", Toast.LENGTH_SHORT).show()
            else if (upi.text.toString().trim().isEmpty()) Toast.makeText(this, "Enter UPI ID", Toast.LENGTH_SHORT).show()
            else Toast.makeText(this, "Demo request only. No real payout was sent.", Toast.LENGTH_LONG).show()
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun statusMaker() {
        base("Status Maker")
        val message = input("Write your status", "Good Morning ❤️")
        val size = input("Text size", "52")
        root.addView(message); root.addView(size)
        val preview = text("Preview will appear here", 24f, true)
        preview.gravity = Gravity.CENTER
        preview.setPadding(dp(10), dp(45), dp(10), dp(45))
        root.addView(preview)
        root.addView(button("Preview") {
            preview.text = message.text.toString()
            preview.textSize = size.text.toString().toFloatOrNull() ?: 52f
        })
        root.addView(button("Download Status Image") {
            afterDownload {
                val bmp = canvasImage(message.text.toString(), size.text.toString().toFloatOrNull() ?: 52f, "STATUS")
                saveBitmap(bmp, "Status_${System.currentTimeMillis()}.png")
            }
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun wedding() {
        base("Wedding Card Generator")
        val bride = input("Bride name", "Bride")
        val groom = input("Groom name", "Groom")
        val date = input("Date", "20 December 2026")
        val time = input("Time", "7:00 PM")
        val venue = input("Venue", "Your Wedding Venue")
        val msg = input("Message", "With love and blessings, please join us.")
        listOf(bride,groom,date,time,venue,msg).forEach { root.addView(it) }
        val preview = text("", 18f)
        root.addView(preview)
        val render = {
            preview.text = "${bride.text} ❤️ ${groom.text}\n\n${msg.text}\n\nDate: ${date.text}\nTime: ${time.text}\nVenue: ${venue.text}"
        }
        root.addView(button("Preview Card") { render() })
        root.addView(button("Download Wedding Card") {
            afterDownload {
                val content = "${bride.text} ❤️ ${groom.text}\n\n${msg.text}\n\nDate: ${date.text}\nTime: ${time.text}\nVenue: ${venue.text}"
                saveBitmap(canvasImage(content, 42f, "WEDDING INVITATION"), "Wedding_${System.currentTimeMillis()}.png")
            }
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun invoice() {
        base("GST Invoice Maker")
        val seller = input("Business name", "My Business")
        val sellerGstin = input("Seller GSTIN", "")
        val customer = input("Customer name", "Customer")
        val customerGstin = input("Customer GSTIN", "")
        val product = input("Product / Ad Product", "Product")
        val qty = input("Quantity", "1")
        val rate = input("Rate", "1000")
        val gst = input("GST %", "18")
        listOf(seller,sellerGstin,customer,customerGstin,product,qty,rate,gst).forEach { root.addView(it) }
        val result = text("", 17f, true)
        root.addView(result)
        fun calc(): Triple<Double,Double,Double> {
            val q = qty.text.toString().toDoubleOrNull() ?: 0.0
            val r = rate.text.toString().toDoubleOrNull() ?: 0.0
            val g = gst.text.toString().toDoubleOrNull() ?: 0.0
            val sub = q*r
            val tax = sub*g/100
            return Triple(sub,tax,sub+tax)
        }
        root.addView(button("Calculate Invoice") {
            val (sub,tax,total) = calc()
            result.text = "Subtotal: ₹%.2f\nGST: ₹%.2f\nGrand Total: ₹%.2f".format(sub,tax,total)
        })
        root.addView(button("Download Invoice") {
            afterDownload {
                val (sub,tax,total) = calc()
                val content = "GST INVOICE\n\nSeller: ${seller.text}\nSeller GSTIN: ${sellerGstin.text}\nCustomer: ${customer.text}\nCustomer GSTIN: ${customerGstin.text}\n\nProduct / Ad Product: ${product.text}\nQty: ${qty.text}\nRate: ₹${rate.text}\nGST: ${gst.text}%\n\nSubtotal: ₹%.2f\nGST: ₹%.2f\nGrand Total: ₹%.2f".format(sub,tax,total)
                saveBitmap(canvasImage(content, 30f, "GST INVOICE"), "Invoice_${System.currentTimeMillis()}.png")
            }
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun twoNumberTool(title: String, hintA: String, hintB: String, op: (Double,Double)->Double) {
        base(title)
        val a = input(hintA); val b = input(hintB)
        root.addView(a); root.addView(b)
        val out = text("Result: ", 20f, true); root.addView(out)
        root.addView(button("Calculate") {
            val x=a.text.toString().toDoubleOrNull() ?: 0.0
            val y=b.text.toString().toDoubleOrNull() ?: 0.0
            out.text = "Result: %.2f".format(op(x,y))
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun gstCalculator() = twoNumberTool("GST Calculator", "Amount", "GST %") { a,g -> a*g/100 + a }
    private fun discount() = twoNumberTool("Discount Calculator", "Original price", "Discount %") { p,d -> p - p*d/100 }
    private fun tip() = twoNumberTool("Tip Calculator", "Bill amount", "Tip %") { b,t -> b + b*t/100 }

    private fun calculator() {
        base("Basic Calculator")
        val a=input("First number"); val b=input("Second number")
        root.addView(a); root.addView(b)
        val out=text("Result:",20f,true); root.addView(out)
        listOf("+","−","×","÷").forEach { symbol ->
            root.addView(button(symbol) {
                val x=a.text.toString().toDoubleOrNull() ?: 0.0
                val y=b.text.toString().toDoubleOrNull() ?: 0.0
                val r=when(symbol) { "+"->x+y; "−"->x-y; "×"->x*y; else->if(y==0.0) Double.NaN else x/y }
                out.text="Result: %.4f".format(r)
            })
        }
        root.addView(button("← Home") { showHome() })
    }

    private fun emi() {
        base("EMI Calculator")
        val p=input("Loan amount"); val rate=input("Annual interest %"); val years=input("Years")
        root.addView(p);root.addView(rate);root.addView(years)
        val out=text("",19f,true);root.addView(out)
        root.addView(button("Calculate EMI") {
            val principal=p.text.toString().toDoubleOrNull()?:0.0
            val annual=rate.text.toString().toDoubleOrNull()?:0.0
            val n=(years.text.toString().toDoubleOrNull()?:0.0)*12
            val r=annual/1200
            val e=if(n<=0)0.0 else if(r==0.0) principal/n else principal*r*(1+r).pow(n)/((1+r).pow(n)-1)
            out.text="Monthly EMI: ₹%.2f\nTotal payment: ₹%.2f".format(e,e*n)
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun age() {
        base("Age Calculator")
        val dob=input("Date of birth (dd/MM/yyyy)")
        root.addView(dob)
        val out=text("",19f,true);root.addView(out)
        root.addView(button("Calculate Age") {
            try {
                val d=SimpleDateFormat("dd/MM/yyyy",Locale.US).apply{isLenient=false}.parse(dob.text.toString())!!
                val now=Calendar.getInstance(); val birth=Calendar.getInstance().apply{time=d}
                var y=now.get(Calendar.YEAR)-birth.get(Calendar.YEAR)
                if(now.get(Calendar.DAY_OF_YEAR)<birth.get(Calendar.DAY_OF_YEAR)) y--
                out.text="Age: $y years"
            } catch(e:Exception){ out.text="Use format dd/MM/yyyy" }
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun bmi() {
        base("BMI Calculator")
        val kg=input("Weight (kg)"); val cm=input("Height (cm)")
        root.addView(kg);root.addView(cm)
        val out=text("",19f,true);root.addView(out)
        root.addView(button("Calculate BMI") {
            val w=kg.text.toString().toDoubleOrNull()?:0.0
            val h=(cm.text.toString().toDoubleOrNull()?:0.0)/100
            if(h<=0) out.text="Enter valid height"
            else {
                val v=w/(h*h)
                val cat=when {v<18.5->"Underweight";v<25->"Normal";v<30->"Overweight";else->"Obesity"}
                out.text="BMI: %.1f\nCategory: $cat".format(v)
            }
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun quote() {
        base("Quote Maker")
        val q=input("Quote text","Believe in yourself.")
        val by=input("Author","PickPrime")
        root.addView(q);root.addView(by)
        root.addView(button("Download Quote Image") {
            afterDownload { saveBitmap(canvasImage("\"${q.text}\"\\n\\n— ${by.text}", 44f, "QUOTE"), "Quote_${System.currentTimeMillis()}.png") }
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun nameStyle() {
        base("Name Style Maker")
        val n=input("Enter your name","Rambeer")
        val out=text("",20f,true);root.addView(n);root.addView(out)
        root.addView(button("Generate Styles") {
            val s=n.text.toString()
            out.text="★ $s ★\n✦ $s ✦\n『$s』\n꧁ $s ꧂\n♡ $s ♡"
        })
        root.addView(button("← Home") { showHome() })
    }

    private fun canvasImage(content:String, textSize:Float, heading:String): Bitmap {
        val w=1080; val h=1350
        val bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
        val c=Canvas(bmp)
        c.drawColor(Color.WHITE)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=purple;typeface=Typeface.DEFAULT_BOLD;textSize=62f}
        c.drawText(heading,70f,110f,paint)
        paint.color=Color.DKGRAY;paint.typeface=Typeface.DEFAULT;textSize=textSize
        var y=210f
        val maxChars=36
        content.split("\n").forEach { line ->
            if(line.isEmpty()){y+=35;return@forEach}
            var rest=line
            while(rest.length>maxChars){
                c.drawText(rest.substring(0,maxChars),70f,y,paint);y+=textSize*1.45f;rest=rest.substring(maxChars)
            }
            c.drawText(rest,70f,y,paint);y+=textSize*1.45f
        }
        paint.textSize=28f;paint.color=Color.GRAY
        c.drawText("Created with Watch Video & Earn Real Money",70f,1280f,paint)
        return bmp
    }

    private fun saveBitmap(bitmap: Bitmap, fileName:String) {
        val values=ContentValues().apply{
            put(MediaStore.Images.Media.DISPLAY_NAME,fileName)
            put(MediaStore.Images.Media.MIME_TYPE,"image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/WatchVideoEarn")
        }
        val uri:Uri?=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)
        if(uri!=null){
            contentResolver.openOutputStream(uri)?.use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
            Toast.makeText(this,"Saved to Pictures/WatchVideoEarn",Toast.LENGTH_LONG).show()
        } else Toast.makeText(this,"Could not save image",Toast.LENGTH_SHORT).show()
    }
}
